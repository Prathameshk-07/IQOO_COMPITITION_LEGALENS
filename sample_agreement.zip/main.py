import os
import shutil
import uuid
import json
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Header, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
import pypdf
from dotenv import load_dotenv

# Load services
import db_service
from supabase_service import SupabaseService
from gemini_service import GeminiService

load_dotenv()

app = FastAPI(title="LegalLens Document Intelligence API")

# CORS middleware for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Authentication Dependency
def get_current_user(authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authentication token.")
    
    token = authorization.split(" ")[1]
    try:
        user_info = SupabaseService.verify_token(token)
        # Upsert user record locally in SQLite to maintain foreign key integrity
        user_id = user_info["id"]
        email = user_info["email"]
        full_name = user_info.get("user_metadata", {}).get("full_name", "")
        db_service.upsert_user(user_id, email, full_name)
        return user_info
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

# --- API Routes ---

# Auth Endpoint: SignUp
@app.post("/api/auth/signup")
def signup(payload: Dict[str, str]):
    email = payload.get("email")
    password = payload.get("password")
    full_name = payload.get("full_name")
    
    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password are required.")
        
    try:
        res = SupabaseService.sign_up(email, password, full_name)
        # If user object is returned directly, sync database
        user_data = res.get("user")
        if user_data:
            db_service.upsert_user(user_data["id"], user_data["email"], full_name)
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Auth Endpoint: LogIn
@app.post("/api/auth/login")
def login(payload: Dict[str, str]):
    email = payload.get("email")
    password = payload.get("password")
    
    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password are required.")
        
    try:
        res = SupabaseService.login(email, password)
        user_data = res.get("user")
        if user_data:
            # Sync user locally
            full_name = user_data.get("user_metadata", {}).get("full_name", "")
            db_service.upsert_user(user_data["id"], user_data["email"], full_name)
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Auth Endpoint: Fetch Current Profile
@app.get("/api/auth/me")
def me(current_user: Dict[str, Any] = Depends(get_current_user)):
    user_id = current_user["id"]
    conn = db_service.get_db_connection()
    user_row = conn.execute("SELECT * FROM users WHERE id = ?;", (user_id,)).fetchone()
    conn.close()
    if user_row:
        return dict(user_row)
    return {"id": user_id, "email": current_user["email"]}

# Auth Endpoint: LogOut
@app.post("/api/auth/logout")
def logout(authorization: Optional[str] = Header(None)):
    if authorization and authorization.startswith("Bearer "):
        token = authorization.split(" ")[1]
        SupabaseService.logout(token)
    return {"message": "Logged out successfully."}

# Chat Endpoint: Get Conversations List
@app.get("/api/conversations")
def list_conversations(current_user: Dict[str, Any] = Depends(get_current_user)):
    return db_service.get_conversations_by_user(current_user["id"])

# Chat Endpoint: Create Conversation
@app.post("/api/conversations")
def create_conversation(payload: Dict[str, str], current_user: Dict[str, Any] = Depends(get_current_user)):
    title = payload.get("title", "New Chat")
    return db_service.create_conversation(current_user["id"], title)

# Chat Endpoint: Delete Conversation
@app.delete("/api/conversations/{conv_id}")
def delete_conversation(conv_id: str, current_user: Dict[str, Any] = Depends(get_current_user)):
    success = db_service.delete_conversation(conv_id, current_user["id"])
    if not success:
        raise HTTPException(status_code=404, detail="Conversation not found or unauthorized.")
    return {"message": "Conversation deleted successfully."}

# Chat Endpoint: Update Conversation Title
@app.patch("/api/conversations/{conv_id}")
def update_conversation(conv_id: str, payload: Dict[str, str], current_user: Dict[str, Any] = Depends(get_current_user)):
    title = payload.get("title")
    if not title:
        raise HTTPException(status_code=400, detail="Title is required.")
    
    # Verify owner
    conv = db_service.get_conversation(conv_id)
    if not conv or conv["user_id"] != current_user["id"]:
        raise HTTPException(status_code=404, detail="Conversation not found.")
        
    updated = db_service.update_conversation_title(conv_id, title)
    return updated

# Chat Endpoint: Get Message History
@app.get("/api/conversations/{conv_id}/messages")
def get_messages(conv_id: str, current_user: Dict[str, Any] = Depends(get_current_user)):
    return db_service.get_messages_by_conversation(conv_id, current_user["id"])

# Chat Endpoint: Update Conversation Document Type
@app.patch("/api/conversations/{conv_id}/document-type")
def update_document_type(
    conv_id: str,
    payload: Dict[str, str],
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    user_id = current_user["id"]
    doc_type = payload.get("document_type")
    if not doc_type:
        raise HTTPException(status_code=400, detail="document_type is required.")
        
    conv = db_service.get_conversation(conv_id)
    if not conv or conv["user_id"] != user_id:
        raise HTTPException(status_code=404, detail="Conversation not found or unauthorized.")
        
    updated = db_service.update_conversation_document_type(conv_id, doc_type)
    return updated

# Document Compare Endpoint
@app.post("/api/documents/compare")
def compare_documents(
    payload: Dict[str, Any],
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    user_id = current_user["id"]
    doc_ids = payload.get("document_ids", [])
    language = payload.get("language", "English")
    doc_type = payload.get("document_type", "Legal Agreement")
    
    if len(doc_ids) < 2:
        raise HTTPException(status_code=400, detail="Select at least two documents to compare.")
        
    docs_data = []
    for d_id in doc_ids:
        doc = db_service.get_document(d_id, user_id)
        if not doc:
            raise HTTPException(status_code=404, detail=f"Document not found or unauthorized: {d_id}")
        docs_data.append(dict(doc))
        
    try:
        comparison_result = GeminiService.compare_documents(docs_data, doc_type, language)
        return comparison_result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to compare documents: {str(e)}")

# Background resume processing helper (runs heavy summary, analysis, chunk indexing)
def process_document_background_resume(
    doc_id: str,
    user_id: str,
    conversation_id: str,
    filename: str,
    temp_path: str,
    is_pdf: bool,
    full_text: str,
    doc_type: str,
    page_count: int,
    file_content: bytes,
    content_type: str,
    language: str = "English"
):
    try:
        db_service.update_document_status(doc_id, user_id, status="processing")
        
        # 1. Upload to Gemini Files API if page count is small
        gemini_file_uri = None
        if page_count <= 15:
            try:
                gemini_file_uri = GeminiService.upload_file_to_gemini(filename, file_content, content_type)
            except Exception as upload_err:
                print("Error uploading to Gemini Files API:", upload_err)
                
        # 2. Dynamic Document Analysis and Summary Generation
        summary = "No summary could be generated."
        extracted_json_str = "{}"
        if full_text.strip():
            try:
                analysis_context = full_text[:30000]
                analysis = GeminiService.analyze_document(analysis_context, doc_type, language)
                summary = analysis.get("summary", "Document summary is unavailable.")
                
                analysis_data = {
                    "extracted_info": analysis.get("extracted_info", {}),
                    "missing_info": analysis.get("missing_info", []),
                    "action_items": analysis.get("action_items", [])
                }
                extracted_json_str = json.dumps(analysis_data)
            except Exception as analysis_err:
                print("Error during document auto-analysis:", analysis_err)
                
        # 3. Generate chunks and embeddings (RAG index) concurrently
        chunks = []
        if full_text.strip():
            if is_pdf:
                try:
                    with open(temp_path, "rb") as pdf_file:
                        reader = pypdf.PdfReader(pdf_file)
                        for page_idx, page in enumerate(reader.pages):
                            page_text = page.extract_text() or ""
                            page_num = page_idx + 1
                            
                            char_idx = 0
                            chunk_idx = 0
                            while char_idx < len(page_text):
                                chunk_content = page_text[char_idx : char_idx + 1000]
                                if not chunk_content.strip():
                                    char_idx += 800
                                    continue
                                chunks.append({
                                    "document_id": doc_id,
                                    "page_number": page_num,
                                    "chunk_index": chunk_idx,
                                    "content": chunk_content
                                })
                                char_idx += 800
                                chunk_idx += 1
                except Exception as e:
                    print("Error page chunking PDF:", e)
            else:
                char_idx = 0
                chunk_idx = 0
                while char_idx < len(full_text):
                    chunk_content = full_text[char_idx : char_idx + 1000]
                    if chunk_content.strip():
                        chunks.append({
                            "document_id": doc_id,
                            "page_number": 1,
                            "chunk_index": chunk_idx,
                            "content": chunk_content
                        })
                    char_idx += 800
                    chunk_idx += 1
                    
        # Generate embeddings in parallel (ThreadPoolExecutor inside generate_embeddings_pool)
        if chunks:
            try:
                chunks = GeminiService.generate_embeddings_pool(chunks)
                db_service.insert_document_chunks(chunks)
            except Exception as embed_err:
                print("Error calculating chunk embeddings concurrently:", embed_err)
                
        # 4. Save metadata update and change status to ready
        db_service.update_document_status(
            doc_id=doc_id,
            user_id=user_id,
            status="ready",
            summary=summary,
            extracted_info=extracted_json_str,
            gemini_file_uri=gemini_file_uri
        )
        
        # 5. Insert Summary Message into the conversation stream
        db_service.create_message(
            conversation_id=conversation_id,
            sender="assistant",
            content=f"### 📄 Document Summary: {filename}\n\n{summary}\n\n*(Note: Key fields, action items, and missing information can be viewed in the collapsible 'Important Information' side panel.)*"
        )
    except Exception as e:
        print(f"Background processing failure resume for doc {doc_id}: {e}")
        db_service.update_document_status(doc_id, user_id, status="error")
    finally:
        # Cleanup temp file
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception as clean_err:
                print("Error cleaning up temp file:", clean_err)

# Initial background document classifier and mismatch verifier
def process_document_background(
    doc_id: str,
    user_id: str,
    conversation_id: str,
    filename: str,
    storage_path: str,
    temp_path: str,
    is_pdf: bool,
    full_text: str,
    doc_type: str,
    page_count: int,
    file_content: bytes,
    content_type: str,
    language: str = "English"
):
    try:
        # Update status to processing in background
        db_service.update_document_status(doc_id, user_id, status="processing")
        
        # Run mismatch classifier
        mismatch_res = GeminiService.detect_document_type_mismatch(full_text, doc_type)
        if mismatch_res.get("mismatch_detected", False):
            # Mismatch detected! Save state parameters and suspend processing
            db_service.update_document_status(
                doc_id=doc_id,
                user_id=user_id,
                status="mismatch",
                detected_type=mismatch_res.get("detected_type"),
                mismatch_message=mismatch_res.get("message")
            )
            return
            
        # Resume remaining indexing operations directly if matching expects
        process_document_background_resume(
            doc_id=doc_id,
            user_id=user_id,
            conversation_id=conversation_id,
            filename=filename,
            temp_path=temp_path,
            is_pdf=is_pdf,
            full_text=full_text,
            doc_type=doc_type,
            page_count=page_count,
            file_content=file_content,
            content_type=content_type,
            language=language
        )
    except Exception as e:
        print(f"Background processing failure for doc {doc_id}: {e}")
        db_service.update_document_status(doc_id, user_id, status="error")
        if os.path.exists(temp_path):
            os.remove(temp_path)

# Document Upload Endpoint
@app.post("/api/documents/upload")
async def upload_document(
    background_tasks: BackgroundTasks,
    conversation_id: str = Form(...),
    file: UploadFile = File(...),
    language: str = Form("English"),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    user_id = current_user["id"]
    
    # Verify conversation ownership and get active document type
    conv = db_service.get_conversation(conversation_id)
    if not conv or conv["user_id"] != user_id:
        raise HTTPException(status_code=404, detail="Conversation not found or unauthorized.")
    doc_type = conv.get("document_type", "Legal Agreement")
        
    # Read file data
    file_content = await file.read()
    file_size = len(file_content)
    filename = file.filename
    
    # --- CACHING CHECK (Check if identical document is already fully processed) ---
    existing_doc = db_service.get_document_by_name_and_size(user_id, filename, file_size)
    if existing_doc:
        print(f"Cache hit: reusing processed document reference for {filename}")
        new_doc_id = str(uuid.uuid4())
        new_storage_path = existing_doc["storage_path"]
        
        # 1. Create duplicate SQLite document record instantly marked as 'ready'
        doc_record = db_service.create_document(
            doc_id=new_doc_id,
            user_id=user_id,
            conversation_id=conversation_id,
            filename=filename,
            file_size=file_size,
            storage_path=new_storage_path,
            gemini_file_uri=existing_doc["gemini_file_uri"],
            full_text=existing_doc["full_text"],
            summary=existing_doc["summary"],
            extracted_info=existing_doc["extracted_info"],
            status="ready"
        )
        
        # 2. Duplicate chunks instantly
        db_service.duplicate_document_chunks(existing_doc["id"], new_doc_id)
        
        # 3. Auto-insert summary message
        db_service.create_message(
            conversation_id=conversation_id,
            sender="assistant",
            content=f"### 📄 Document Summary (Cached): {filename}\n\n{existing_doc['summary']}\n\n*(Note: Key fields, action items, and missing information can be viewed in the collapsible 'Important Information' side panel.)*"
        )
        return doc_record
        
    # Cache miss: process file
    temp_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "temp")
    os.makedirs(temp_dir, exist_ok=True)
    temp_path = os.path.join(temp_dir, f"{uuid.uuid4()}_{filename}")
    
    with open(temp_path, "wb") as f:
        f.write(file_content)
        
    page_count = 1
    is_pdf = filename.lower().endswith(".pdf")
    full_text = ""
    
    if is_pdf:
        try:
            with open(temp_path, "rb") as pdf_file:
                reader = pypdf.PdfReader(pdf_file)
                page_count = len(reader.pages)
                
                # Extract text for analysis and raw content search
                text_parts = []
                for page in reader.pages:
                    page_text = page.extract_text() or ""
                    text_parts.append(page_text)
                full_text = "\n".join(text_parts)
        except Exception as e:
            print("Error parsing PDF page count and text:", e)
    else:
        try:
            full_text = file_content.decode("utf-8", errors="ignore")
        except Exception as e:
            print("Error reading plain text file:", e)
            
    doc_id = str(uuid.uuid4())
    storage_path = f"{user_id}/{conversation_id}/{doc_id}_{filename}"
    
    try:
        # 1. Upload original document to Supabase Storage
        content_type = file.content_type or ("application/pdf" if is_pdf else "text/plain")
        SupabaseService.upload_document(storage_path, file_content, content_type)
        
        # 2. Save document record in SQLite immediately with status 'processing'
        doc_record = db_service.create_document(
            doc_id=doc_id,
            user_id=user_id,
            conversation_id=conversation_id,
            filename=filename,
            file_size=file_size,
            storage_path=storage_path,
            full_text=full_text,
            summary="Processing Summary...",
            extracted_info="{}",
            status="processing"
        )
        
        # 3. Add background task to handle heavy computations (embeddings, Gemini analyze)
        background_tasks.add_task(
            process_document_background,
            doc_id=doc_id,
            user_id=user_id,
            conversation_id=conversation_id,
            filename=filename,
            storage_path=storage_path,
            temp_path=temp_path,
            is_pdf=is_pdf,
            full_text=full_text,
            doc_type=doc_type,
            page_count=page_count,
            file_content=file_content,
            content_type=content_type,
            language=language
        )
        
        return doc_record
        
    except Exception as e:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise HTTPException(status_code=500, detail=f"Unable to initiate document upload: {str(e)}")

# Confirm or Resolve Document Type Mismatches
@app.post("/api/documents/{doc_id}/confirm")
def confirm_mismatch(
    doc_id: str,
    payload: Dict[str, Any],
    background_tasks: BackgroundTasks,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    user_id = current_user["id"]
    action = payload.get("action") # 'force', 'change', or 'cancel'
    language = payload.get("language", "English")
    
    doc = db_service.get_document(doc_id, user_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
        
    if doc["status"] != "mismatch":
        raise HTTPException(status_code=400, detail="Document is not in a mismatch state.")
        
    conversation_id = doc["conversation_id"]
    filename = doc["filename"]
    storage_path = doc["storage_path"]
    full_text = doc["full_text"]
    
    # Locate/reconstruct the local temp file path
    temp_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "temp")
    temp_path = ""
    if os.path.exists(temp_dir):
        for f in os.listdir(temp_dir):
            if f.endswith(filename):
                temp_path = os.path.join(temp_dir, f)
                break
                
    if not temp_path or not os.path.exists(temp_path):
        os.makedirs(temp_dir, exist_ok=True)
        temp_path = os.path.join(temp_dir, f"{uuid.uuid4()}_{filename}")
        with open(temp_path, "w", encoding="utf-8", errors="ignore") as f:
            f.write(full_text or "")
            
    is_pdf = filename.lower().endswith(".pdf")
    page_count = 1
    if is_pdf:
        try:
            with open(temp_path, "rb") as pdf_file:
                reader = pypdf.PdfReader(pdf_file)
                page_count = len(reader.pages)
        except:
            pass
            
    # Re-retrieve Supabase document bytes
    file_content = b""
    try:
        file_content = SupabaseService.download_document(storage_path)
    except Exception as e:
        print("Supabase download failed during confirmation, using raw text fallback:", e)
        file_content = (full_text or "").encode("utf-8", errors="ignore")
        
    content_type = "application/pdf" if is_pdf else "text/plain"
    
    if action == "force":
        conv = db_service.get_conversation(conversation_id)
        doc_type = conv.get("document_type", "Legal Agreement") if conv else "Legal Agreement"
        
        db_service.update_document_status(doc_id, user_id, status="processing", detected_type="", mismatch_message="")
        
        background_tasks.add_task(
            process_document_background_resume,
            doc_id=doc_id,
            user_id=user_id,
            conversation_id=conversation_id,
            filename=filename,
            temp_path=temp_path,
            is_pdf=is_pdf,
            full_text=full_text,
            doc_type=doc_type,
            page_count=page_count,
            file_content=file_content,
            content_type=content_type,
            language=language
        )
        return {"status": "processing", "message": "Resumed analysis as originally selected type."}
        
    elif action == "change":
        detected_type = doc.get("detected_type")
        if not detected_type:
            raise HTTPException(status_code=400, detail="No detected type found to switch to.")
            
        db_service.update_conversation_document_type(conversation_id, detected_type)
        db_service.update_document_status(doc_id, user_id, status="processing", detected_type="", mismatch_message="")
        
        background_tasks.add_task(
            process_document_background_resume,
            doc_id=doc_id,
            user_id=user_id,
            conversation_id=conversation_id,
            filename=filename,
            temp_path=temp_path,
            is_pdf=is_pdf,
            full_text=full_text,
            doc_type=detected_type,
            page_count=page_count,
            file_content=file_content,
            content_type=content_type,
            language=language
        )
        return {"status": "processing", "message": f"Resumed analysis after switching conversation mode to {detected_type}."}
        
    elif action == "cancel":
        try:
            SupabaseService.delete_document(storage_path)
        except Exception as delete_err:
            print("Supabase file cleanup warning:", delete_err)
            
        db_service.delete_document(doc_id, user_id)
        if os.path.exists(temp_path):
            os.remove(temp_path)
            
        return {"status": "cancelled", "message": "Upload cancelled and document deleted."}
        
    else:
        raise HTTPException(status_code=400, detail="Invalid confirmation action.")

# Document Search Endpoint
@app.get("/api/documents/search")
def search_documents(query: Optional[str] = "", current_user: Dict[str, Any] = Depends(get_current_user)):
    user_id = current_user["id"]
    if not query or not query.strip():
        return db_service.search_user_documents(user_id, "")
        
    try:
        query_embedding = GeminiService.generate_embeddings(query)
        matching_chunks = db_service.semantic_search_chunks(user_id, query_embedding, limit=10)
        
        results = []
        for chunk in matching_chunks:
            results.append({
                "document_id": chunk["document_id"],
                "filename": chunk["filename"],
                "conversation_id": chunk["conversation_id"],
                "page_number": chunk["page_number"],
                "content": chunk["content"],
                "similarity": chunk["similarity"]
            })
        return results
    except Exception as err:
        print("Semantic search error (falling back to filename search):", err)
        return db_service.search_user_documents(user_id, query)

# Get Single Document Status
@app.get("/api/documents/{doc_id}")
def get_document_status(doc_id: str, current_user: Dict[str, Any] = Depends(get_current_user)):
    doc = db_service.get_document(doc_id, current_user["id"])
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
    return doc

# Delete single document endpoint
@app.delete("/api/documents/{doc_id}")
def delete_document_route(doc_id: str, current_user: Dict[str, Any] = Depends(get_current_user)):
    user_id = current_user["id"]
    doc = db_service.get_document(doc_id, user_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
        
    try:
        SupabaseService.delete_document(doc["storage_path"])
    except Exception as e:
        print("Error deleting document from Supabase storage:", e)
        
    db_service.delete_document(doc_id, user_id)
    return {"status": "success", "message": "Document deleted successfully."}

# Chat Send Message Endpoint
@app.post("/api/conversations/{conv_id}/send")
def send_message(
    conv_id: str,
    payload: Dict[str, Any],
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    user_id = current_user["id"]
    prompt = payload.get("prompt")
    file_id = payload.get("file_id") # optional attached document in this turn
    search_grounding = payload.get("search_grounding", False)
    language = payload.get("language", "English")
    
    if not prompt or not prompt.strip():
        raise HTTPException(status_code=400, detail="Prompt is required.")
        
    # Verify conversation ownership
    conv = db_service.get_conversation(conv_id)
    if not conv or conv["user_id"] != user_id:
        raise HTTPException(status_code=404, detail="Conversation not found.")
    doc_type = conv.get("document_type", "Legal Agreement")
        
    # Get document information inside the current conversation
    conv_docs = db_service.get_documents_by_conversation(conv_id, user_id)
    
    # Filter documents to find ones with chunks for RAG context
    # If the user specifically attached a file, prioritize it!
    # Otherwise, use all documents in the conversation
    rag_doc_ids = []
    if file_id:
        rag_doc_ids = [file_id]
    elif conv_docs:
        # Strict context boundary: use ONLY the active document of this conversation
        rag_doc_ids = [conv_docs[-1]["id"]]
        
    # Build RAG Context
    rag_context_text = ""
    matching_chunks = []
    if rag_doc_ids:
        try:
            # Generate embedding for the user prompt
            query_embedding = GeminiService.generate_embeddings(prompt)
            # Retrieve top 5 matching chunks from RAG database
            matching_chunks = db_service.retrieve_similar_chunks(user_id, conv_id, rag_doc_ids, query_embedding, limit=5)
            
            if matching_chunks:
                context_parts = []
                for chunk in matching_chunks:
                    context_parts.append(
                        f"[Document: {chunk['filename']} | Page: {chunk['page_number']}]:\n{chunk['content']}"
                    )
                rag_context_text = "\n\n---\n**RETRIEVED DOCUMENT CONTEXT**:\n" + "\n\n".join(context_parts) + "\n---\n\n"
        except Exception as rag_err:
            print("RAG Retrieval error:", rag_err)
            
    # Prepend RAG context to the prompt if retrieved
    final_prompt = prompt
    if rag_context_text:
        final_prompt = (
            f"Use the following retrieved document context to answer the user's prompt as accurately as possible. "
            f"If the information is not present in the context, use your general knowledge, but prioritize the document context. "
            f"Cite the filename and page numbers in your references.\n"
            f"{rag_context_text}"
            f"User Prompt: {prompt}"
        )
        
    # Retrieve previous conversation messages for memory
    messages_history = db_service.get_messages_by_conversation(conv_id, user_id)
    
    # Save the User's message in local SQLite
    db_service.create_message(conv_id, "user", prompt, file_id)
    
    # Streaming response generator
    def stream_event_generator():
        try:
            accumulated_chunks = []
            
            # Request streaming generation from Gemini
            stream_gen = GeminiService.generate_streaming_response(
                prompt=final_prompt,
                conversation_history=messages_history,
                active_gemini_file_uris=None, # Do not send the full file URI, use chunk context
                search_grounding=search_grounding,
                language=language,
                document_type=doc_type
            )
            
            for chunk_text in stream_gen:
                accumulated_chunks.append(chunk_text)
                # Yield SSE chunk
                data = json.dumps({"text": chunk_text})
                yield f"data: {data}\n\n"
                
            full_assistant_response = "".join(accumulated_chunks)
            
            # Build citations
            sources = []
            if rag_context_text and matching_chunks:
                for chunk in matching_chunks[:3]:
                    citation = {
                        "title": f"{chunk['filename']} — Page {chunk['page_number']}",
                        "url": "#",
                        "type": "document"
                    }
                    if citation not in sources:
                        sources.append(citation)
                        
            # Save Assistant message in SQLite
            db_service.create_message(conv_id, "assistant", full_assistant_response, None)
            
            # Yield final citations
            yield f"data: {json.dumps({'sources': sources})}\n\n"
            
        except Exception as e:
            err_msg = f"**Error**: AI response streaming failed: {str(e)}"
            db_service.create_message(conv_id, "assistant", err_msg, None)
            yield f"data: {json.dumps({'text': err_msg})}\n\n"
            
    return StreamingResponse(stream_event_generator(), media_type="text/event-stream")

# Serve Frontend static files
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def read_root():
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "LegalLens Backend Running. Please ensure frontend static directory is populated."}
